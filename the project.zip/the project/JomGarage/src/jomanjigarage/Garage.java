package jomanjigarage;

import java.util.Scanner;



/**
 *
 * @author John
 */



   
public class Garage {
    

    
    
    Scanner sc = new Scanner(System.in);

    // Attributes 
    static int[][] Places = new int[4][5];
    static int ID = 1;

    static String[][] vehicle_type = new String[4][5];
    static Object[][] data = new Object[4][5];

    // Constractor 
    public Garage() {
    }

    // Methods
    public void SetPlaceIn() {
        garage:
        {

            for (int i = 0; i < 4; i++) {
                String type;
                String name;
                Object model;
                String x="t" ;
                for (int j = 0; j < 5; j++) {
                    if(x.equals("t")){
                    System.out.println("enter the typ of vehicle (Car or Bus)");
                    type = sc.nextLine();
                    System.out.println("enter the name of" + " " + type + " " + "owner");
                    name = sc.nextLine();
                    System.out.println("enter the model of" + " " + type);
                     model = sc.nextLine();
                    System.out.println("enter the falg t");
                    x=sc.nextLine();
                    if (Places[i][j] == 0) {
                        Places[i][j] = ID;
                        vehicle_type[i][j] = type;
                        data[i][j] = name + model;
                        ID++;
                    }
                    }
                    else{
                        
                       break garage;
                    }   
            }
        }
       
    }
    }
    
    
    public void setPlaceOut(int id) {
        garage:
        {
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 5; j++) {
                    if (Places[i][j] == id) {
                        Places[i][j] = 0;
                        break garage;
                    }
                }
            }
        }
    }

    public int[][] getPlaces() {
        return Places;
    }

//    public void ShowPlaces(){
//        for(int i=0; i<4; i++){
//          System.out.println("");
//          for (int j=0; j<5; j++){
//              System.out.print(Places[i][j]+"\t");
//          }
//      }
//      System.out.println("");
//    }
//    public void Empty_Place(){
//     for(int i=0; i<4; i++){
//            for(int j=0; j<5; j++){
//                if(Places[i][j]==0)
//                    emptyplace[i][j]=false;
//                    else
//                    emptyplace[i][j]=true; }}
//        for(int i=0; i<3; i++){
//            System.out.println("");
//            for(int j=0; j<5; j++){
//                System.out.print(emptyplace[i][j]+"\t");
//            }}
}
