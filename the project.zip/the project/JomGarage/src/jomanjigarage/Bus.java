
package jomanjigarage;
import java.io.PrintWriter;

public class Bus extends Show_Garage {

    
      @Override
     public void CalPrice(int id,PrintWriter pw){
         int DateOut;
         System.out.println("enter the DateOut");
         DateOut=sc.nextInt();
  
         search:
         for(int i=0; i<3; i++){
         for(int j=0; j<5; j++){
            
             if(DateOut-DateIn[i][j]==0){
                 Price=10;
                 pw.println("the price for car with ID "+id+" is "+Price);
                 System.out.println("the price for car with ID "+id+" is "+Price);
             break search;
             }
             
             else if(Places[i][j]==id){
                 Price=(((DateIn[i][j]-DateOut)*10)+20);
                 Places[i][j]=0;
                 pw.println("the price for bus with ID "+id+" is "+Price);
                 System.out.println("the price for bus with ID "+id+" is "+Price);
             break search;
             }
            else
             System.out.println("invalid dateout or id");
             }}
    }
}
