
package jomanjigarage;

import java.io.PrintWriter;


public class Show_Garage extends Vehicle {
    static boolean [][] emptyplace=new boolean[4][5];
    

    
    public void Show_Garage() {
    }

    
    public void Empty_Place(PrintWriter pw){
        for(int i=0; i<3; i++){
            for(int j=0; j<5; j++){
                if(Places[i][j]==0)
                    emptyplace[i][j]=false;
                    else
                    emptyplace[i][j]=true; }}
        for(int i=0; i<4; i++){
            System.out.println("");
            for(int j=0; j<5; j++){
                pw.println("this tell you the place with true and false");
                pw.print(emptyplace[i][j]+"\t");
                System.out.println(emptyplace[i][j]+"\t");
                
            }}
    }
    
    
    public void ShowPlaces(PrintWriter pw){
        for(int i=0; i<4; i++){
          System.out.println("");
          for (int j=0; j<5; j++){
              System.out.print(Places[i][j]+"\t");
              pw.println("this is the garage with ids");
              pw.print(Places[i][j]+"\t");
          }
      }
      System.out.println("");
    }
    
    public void Showtype(PrintWriter pw){
        for(int i=0; i<4; i++){
          System.out.println("");
          for (int j=0; j<5; j++){
              System.out.print(vehicle_type[i][j]+"\t");
              pw.println(vehicle_type[i][j]+"\t");
          }
      }
    }
    
    public void ShowData(PrintWriter pw){
        for(int i=0; i<4; i++){
          System.out.println("");
          for (int j=0; j<5; j++){
              System.out.println("this tell you the data of the car inside the garage");
              pw.println(data[i][j]+"\t");
              System.out.print(data[i][j]+"\t");
          }
      }
    }
    
    public void ShowInDate(){
        for(int i=0; i<4; i++){
          System.out.println("");
          for (int j=0; j<5; j++){
              System.out.print(DateIn[i][j]+"\t");
          }
      }
      System.out.println("");
  }
    
    
    
    public void search_by_place(PrintWriter pw){
       int x;
       int y;
        System.out.println("now you use function search by place");
        System.out.println("enter floor number");
       x=sc.nextInt();
        System.out.println("enter place number");
        y=sc.nextInt();
      
        pw.println("ID: "+Places[x-1][y-1]);
        pw.println("vehicle type: "+vehicle_type[x-1][y-1]);
        pw.println("name & vehicle model: "+data[x-1][y-1]);
        pw.println("day In: "+DateIn[x-1][y-1]);
        
         
        System.out.println("ID: "+Places[x-1][y-1]);
        System.out.println("vehicle type: "+vehicle_type[x-1][y-1]);
        System.out.println("name & vehicle model: "+data[x-1][y-1]);
        System.out.println("day In: "+DateIn[x-1][y-1]);
    }
    
    
    
    public void search_by_id( PrintWriter pw){
       int id;
        System.out.println("now you use search by id");
        System.out.println("enter the ID");
       id=sc.nextInt();

       search:
         for(int i=0; i<3; i++){
         for(int j=0; j<5; j++){
             if(Places[i][j]==id){
                 pw.println("the palce of your car that you use search by id is:");
                   pw.println(Places[i][j]);
                     pw.println(vehicle_type[i][j]);
                       pw.println(data[i][j]);
                       
                        System.out.println("the palce of your car that you use search by id is:");
                   System.out.println(Places[i][j]);
                     System.out.println(vehicle_type[i][j]);
                       System.out.println(data[i][j]);
          
             break search;
             }
             else
             System.out.println("invalid id");
         }}
       
        
        
    }
    
    }
    

