/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jomanjigarage;
import java.io.File;
import java.io.PrintWriter;
import java.io.IOException;

/**
 *
 * @author John
 */
public class JomanjiGarage {

    static  PrintWriter pw;    
    public static void main(String[] args) {
        try{
        File file=new File("ameen.txt");
        
        if(!file.exists())
        {
            file.createNewFile();
        }
        pw=new PrintWriter(file);
        pw.println("garage code :ameen reda ameen ");
     
        }
        catch(IOException e){
        e.printStackTrace();
        }
        
        
Garage g1=new Garage();
Car c1=new Car();
Bus b1=new Bus();


c1.SetPlaceIn();
c1.setDateIn(1, 10);
c1.CalPrice(1, pw);

//b1.SetPlaceIn();
//c1.search_by_place();

//b1.ShowData();

//c1.SetPlaceIn();
//c1.setDateIn(1, 2);
//c1.SetPlaceIn();
//c1.setDateIn(2, 3);
//c1.SetPlaceIn();
//c1.setDateIn(3, 4);
//b1.SetPlaceIn();
//b1.setDateIn(4, 2);
//b1.SetPlaceIn();
//b1.setDateIn(5, 7);
//
//c1.CalPrice(1);
//        System.out.println("");
//        c1.ShowPlaces();
       pw.close();
    }
    
}
