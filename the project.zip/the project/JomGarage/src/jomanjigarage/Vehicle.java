package jomanjigarage;
import java.io.PrintWriter;

public class Vehicle extends Garage{
 
    // Attributes
   static int[][]DateIn=new int[4][5];
     double Price;
    
    
     // Constractor 
    public Vehicle() {
        }
   
  
    // Methods  

    public void setDateIn(int id,int datein) {
        search:
        for(int i=0; i<4; i++){
           for(int j=0; j<5; j++){
        if(Places[i][j]==id){
         DateIn[i][j]=datein;
         break search;
        }}}
    }

    
   
    
    public void CalPrice(int id,PrintWriter pw){};
    
//  public void ShowInDate(){
//        for(int i=0; i<4; i++){
//          System.out.println("");
//          for (int j=0; j<5; j++){
//              System.out.print(DateIn[i][j]+"\t");
//          }
//      }
//      System.out.println("");
//  }
   
   
  
}
    
 