package jomanjigarage;
import java.io.PrintWriter;
public class Car extends Show_Garage{
         
    
     @Override
     public void CalPrice(int id,PrintWriter pw){
    
     int DateOut;
         System.out.println("enter the DateOut");
         DateOut=sc.nextInt();
 
          
         
         search:
         for(int i=0; i<3; i++){
         for(int j=0; j<5; j++){
             
             if(DateOut-DateIn[i][j]==0){
                 Price=10;
                 System.out.println("this calc price of car");
                pw.println("the price for car with ID "+id+" is "+Price);
                 
                 System.out.println("the price for car with ID "+id+" is "+Price);
             
                 break search;
             }
             
             else if(Places[i][j]==id){
                 Price=((DateOut-DateIn[i][j])*10);
                 Places[i][j]=0;
                  pw.println("the price for car with ID "+id+" is "+Price);
                 System.out.println("the price for car with ID "+id+" is "+Price);
             break search;
             }
                     
             else
             System.out.println("invalid dateout or id");
         }}
         
   
    }
}
